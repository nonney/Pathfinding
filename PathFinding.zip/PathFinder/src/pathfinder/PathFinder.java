
package pathfinder;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 
 * @Nonhlanhla Matjiu
 */
public class PathFinder {

   
public char[][] grid;
public String Path;
public int Row;
public int Col;

PathFinder(char[][] aGrid, int stRow, int stCol, String tempPath) {
grid= aGrid;
Row = stRow;
Col = stCol;
Path = tempPath;
    
}

// indicates possible path
void Pathtaken() {
    grid[Row][Col] = '*';
}

// indicates visited path
void visited() {
    grid[Row][Col] = '"';
}


void solveGrid() {
    // check for end
   
    if ((Col + 1 < grid[Row].length && grid[Row][Col + 1] == 'E') ||
            (Col - 1 >= 0  && grid[Row][Col - 1] == 'E') ||
           (Row + 1 < grid[Row].length && grid[Row+ 1][Col] == 'E') ||
            (Row-1 >= 0 && grid[Row -1][Col] == 'E')) {
        return;
    }
    // search east area
    if (Col + 1 < grid[Row].length && searchtopass(Row, Col + 1)) {
        Col++;
        Pathtaken();
        Path += "E"; 
        //continue search
        solveGrid();
        // search west area
    } else if (Col - 1 >= 0 && searchtopass(Row, Col - 1)) {
        Col--;
        Pathtaken();
        Path += "W";
        solveGrid();
        // search  south area
    }  else if (Row + 1 < grid.length && searchtopass(Row + 1, Col)) {
        Row++;
        Pathtaken();
        Path += "S";
        solveGrid();
        // search north area
    }  else if (Row- 1 >= 0 && searchtopass(Row- 1, Col)) {
        Row--;
        Pathtaken();
        Path += "N";
        solveGrid();
    }
    else {             
       // hit W then back track
        visited();
            backTrack();
        }
    }


boolean searchtopass(int x, int y) {
    return grid[x][y] == '.';
}




void backTrack() {
    
    if (Path.length() > 0) {
        visited();
        switch (Path.charAt(Path.length() - 1)) {
        case 'E':
            Col--;
            break;
        case 'W':
            Col++;
            break;
        case 'S':
            Row--;
            break;
        case 'N':
            Row++;
            break;
        }
        Path = Path.substring(0,Path.length()-1);
        solveGrid();    
    }
}

void printGrid() {
    for(int i = 0; i < grid.length; i++) {
        System.out.println(grid[i]);
    }
}  
    
    public static void main(String[] args) throws FileNotFoundException {
    
    
   try
{
    // read text file
FileReader file= new FileReader("C:\\Users\\User\\Documents\\NetBeansProjects\\PathFinder\\map.txt");
BufferedReader line= new BufferedReader(file);
String scanner=" ";
char [] array;
int i=0,j=0;
//initialize array to 2d
char [][] map=new char[50][50];
 System.out.print("Map Sample");
 System.out.print("\n");
while((scanner= line.readLine()) != null) 
{
array=scanner.toCharArray();

        for(j=0;j<array.length;j++)
{
   
map[i][j]=array[j];
//print text file in an array
System.out.print(""+map[i][j]);

System.out.print("");
}
i++;
System.out.print("\n");
}
System.out.print("\n");
String startPath = "S";
    int staX = 1;
    int staY = 1;
    
    //constructor
    PathFinder astar = new PathFinder(map, staX, staY, startPath);
    
    astar.Pathtaken();
    astar.solveGrid();
       System.out.println("One possible path to E: ");
        astar.printGrid();
}
catch(Exception e)
{
e.printStackTrace();
}

   
 
}
}



   
    
    

